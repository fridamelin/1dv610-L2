<?php

class DateTimeView {


	public function show() {

		$timeString = 'TODO, Write servertime here...';

		return '<p>' . $timeString . '</p>';
	}
}